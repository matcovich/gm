<?php $__env->startSection('content'); ?>

    <main id="main-container">
        <?php if(session()->has('flash')): ?>
            <div class="alert alert-success alert-dismissable" role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <h3 class="alert-heading font-size-h4 font-w400"><?php echo e(session('flash')); ?></h3>
                <p class="mb-0"></p>
            </div>

        <?php endif; ?>


        <div class="content">
            <h2 class="content-heading">Crear nuevo usuario:</h2>


            <div class="col-md-12">
                <div class="block">

                    <div class="block-content">

                        <form action="" method="POST">
                            <div class="block-content block-content-full">
                                <?php echo e(csrf_field()); ?>

                                <?php echo e(method_field('PUT')); ?>


                                <div class="form-group mb-50">

                                    <button type="submit" class="btn btn-outline-success  pull-right">Guardar datos</button>

                                    <a href="<?php echo e(route('inicio')); ?>" class="btn btn-outline-primary  pull-right mr-20"> Cancelar</a>
                                </div>

                            </div>

                        </form>

                    </div>
                </div>
            </div>

        </div>


    </main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>