@extends('admin.layout')

@section('content')

    <main id="main-container">
        @if (session()->has('flash'))
            <div class="alert alert-success alert-dismissable" role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <h3 class="alert-heading font-size-h4 font-w400">{{ session('flash') }}</h3>
                <p class="mb-0"></p>
            </div>

        @endif


        <div class="content">
            <h2 class="content-heading">Crear nuevo usuario:</h2>


            <div class="col-md-12">
                <div class="block">

                    <div class="block-content">

                        <form action="" method="POST">
                            <div class="block-content block-content-full">
                                {{ csrf_field() }}
                                {{method_field('PUT')}}

                                <div class="form-group mb-50">

                                    <button type="submit" class="btn btn-outline-success  pull-right">Guardar datos</button>

                                    <a href="{{ route('inicio') }}" class="btn btn-outline-primary  pull-right mr-20"> Cancelar</a>
                                </div>

                            </div>

                        </form>

                    </div>
                </div>
            </div>

        </div>


    </main>

@endsection