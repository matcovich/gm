@extends('admin.layout')
@section('content')

    <main id="main-container">
        <!-- Page Content -->
        <!-- User Info -->
        <div class="bg-image bg-image-bottom" style="background-image: url('/codebase/img/photos/copiapo.jpg');">
            <div class="bg-primary-dark-op py-30">
                <div class="content content-full text-center">
                    <!-- Avatar -->
                    <div class="mb-15">
                        <a class="img-link" href="be_pages_generic_profile.html">
                            <img class="img-avatar img-avatar96 img-avatar-thumb" src="/codebase/img/avatars/avatar15.jpg" alt="">
                        </a>
                    </div>
                    <!-- END Avatar -->

                    <!-- Personal -->
                    <h1 class="h3 text-white font-w700 mb-10"></h1>
                    <h2 class="h5 text-white-op">
                        {{ Auth::user()->name }}
                        <br>
                        <a class="text-primary-light" href="javascript:void(0)">{{ Auth::user()->email }}</a>
                    </h2>
                    <!-- END Personal -->

                    <!-- Actions -->

                    <a href="{{ route('users.create') }}" class="btn btn-rounded btn-hero btn-sm btn-alt-secondary mb-5">
                        <i class="fa fa-user-plus mr-5"></i> Nuevo Cliente
                    </a>
                    <a href="" class="btn btn-rounded btn-hero btn-sm btn-alt-info mb-5 ml-50">
                        <i class="fa fa-car mr-5"></i> Nuevo Vehículo
                    </a>
                    <!-- END Actions -->
                </div>
            </div>
        </div>
        <!-- END User Info -->

        <!-- Main Content -->
        <div class="content bg-white mt-20">
            <!-- tables GM -->
            <h2 class="content-heading">
                <a href="" class="btn btn-sm btn-rounded btn-alt-secondary float-right">Volver</a>
                <i class="si si-briefcase mr-5"></i> Clientes
            </h2>


            <!-- DataTables init on table by adding .js-dataTable-full-pagination class, functionality initialized in js/pages/be_tables_datatables.js -->
            <table class="table table-bordered table-striped table-vcenter js-dataTable-full-pagination">
                <thead>
                <tr>
                    <th class="text-center"></th>
                    <th>Name</th>
                    <th class="d-none d-sm-table-cell">Email</th>
                    <th class="d-none d-sm-table-cell" style="width: 15%;">Access</th>
                    <th class="text-center" style="width: 15%;">Profile</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <td class="text-center">1</td>
                    <td class="font-w600">David Fuller</td>
                    <td class="d-none d-sm-table-cell">customer1@example.com</td>
                    <td class="d-none d-sm-table-cell">
                        <span class="badge badge-primary">Personal</span>
                    </td>
                    <td class="text-center">
                        <button type="button" class="btn btn-sm btn-secondary" data-toggle="tooltip" title="View Customer">
                            <i class="fa fa-user"></i>
                        </button>
                    </td>
                </tr>
                <tr>
                    <td class="text-center">2</td>
                    <td class="font-w600">Alice Moore</td>
                    <td class="d-none d-sm-table-cell">customer2@example.com</td>
                    <td class="d-none d-sm-table-cell">
                        <span class="badge badge-success">VIP</span>
                    </td>
                    <td class="text-center">
                        <button type="button" class="btn btn-sm btn-secondary" data-toggle="tooltip" title="View Customer">
                            <i class="fa fa-user"></i>
                        </button>
                    </td>
                </tr>
                <tr>
                    <td class="text-center">3</td>
                    <td class="font-w600">Henry Harrison</td>
                    <td class="d-none d-sm-table-cell">customer3@example.com</td>
                    <td class="d-none d-sm-table-cell">
                        <span class="badge badge-danger">Disabled</span>
                    </td>
                    <td class="text-center">
                        <button type="button" class="btn btn-sm btn-secondary" data-toggle="tooltip" title="View Customer">
                            <i class="fa fa-user"></i>
                        </button>
                    </td>
                </tr>
                <tr>
                    <td class="text-center">4</td>
                    <td class="font-w600">Judy Ford</td>
                    <td class="d-none d-sm-table-cell">customer4@example.com</td>
                    <td class="d-none d-sm-table-cell">
                        <span class="badge badge-primary">Personal</span>
                    </td>
                    <td class="text-center">
                        <button type="button" class="btn btn-sm btn-secondary" data-toggle="tooltip" title="View Customer">
                            <i class="fa fa-user"></i>
                        </button>
                    </td>
                </tr>
                <tr>
                    <td class="text-center">5</td>
                    <td class="font-w600">Laura Carr</td>
                    <td class="d-none d-sm-table-cell">customer5@example.com</td>
                    <td class="d-none d-sm-table-cell">
                        <span class="badge badge-info">Business</span>
                    </td>
                    <td class="text-center">
                        <button type="button" class="btn btn-sm btn-secondary" data-toggle="tooltip" title="View Customer">
                            <i class="fa fa-user"></i>
                        </button>
                    </td>
                </tr>
                <tr>
                    <td class="text-center">6</td>
                    <td class="font-w600">Albert Ray</td>
                    <td class="d-none d-sm-table-cell">customer6@example.com</td>
                    <td class="d-none d-sm-table-cell">
                        <span class="badge badge-primary">Personal</span>
                    </td>
                    <td class="text-center">
                        <button type="button" class="btn btn-sm btn-secondary" data-toggle="tooltip" title="View Customer">
                            <i class="fa fa-user"></i>
                        </button>
                    </td>
                </tr>
                <tr>
                    <td class="text-center">7</td>
                    <td class="font-w600">Helen Jacobs</td>
                    <td class="d-none d-sm-table-cell">customer7@example.com</td>
                    <td class="d-none d-sm-table-cell">
                        <span class="badge badge-success">VIP</span>
                    </td>
                    <td class="text-center">
                        <button type="button" class="btn btn-sm btn-secondary" data-toggle="tooltip" title="View Customer">
                            <i class="fa fa-user"></i>
                        </button>
                    </td>
                </tr>
                <tr>
                    <td class="text-center">8</td>
                    <td class="font-w600">Danielle Jones</td>
                    <td class="d-none d-sm-table-cell">customer8@example.com</td>
                    <td class="d-none d-sm-table-cell">
                        <span class="badge badge-warning">Trial</span>
                    </td>
                    <td class="text-center">
                        <button type="button" class="btn btn-sm btn-secondary" data-toggle="tooltip" title="View Customer">
                            <i class="fa fa-user"></i>
                        </button>
                    </td>
                </tr>
                <tr>
                    <td class="text-center">9</td>
                    <td class="font-w600">Jose Wagner</td>
                    <td class="d-none d-sm-table-cell">customer9@example.com</td>
                    <td class="d-none d-sm-table-cell">
                        <span class="badge badge-danger">Disabled</span>
                    </td>
                    <td class="text-center">
                        <button type="button" class="btn btn-sm btn-secondary" data-toggle="tooltip" title="View Customer">
                            <i class="fa fa-user"></i>
                        </button>
                    </td>
                </tr>
                <tr>
                    <td class="text-center">10</td>
                    <td class="font-w600">Betty Kelley</td>
                    <td class="d-none d-sm-table-cell">customer10@example.com</td>
                    <td class="d-none d-sm-table-cell">
                        <span class="badge badge-danger">Disabled</span>
                    </td>
                    <td class="text-center">
                        <button type="button" class="btn btn-sm btn-secondary" data-toggle="tooltip" title="View Customer">
                            <i class="fa fa-user"></i>
                        </button>
                    </td>
                </tr>
                <tr>
                    <td class="text-center">11</td>
                    <td class="font-w600">Betty Kelley</td>
                    <td class="d-none d-sm-table-cell">customer11@example.com</td>
                    <td class="d-none d-sm-table-cell">
                        <span class="badge badge-info">Business</span>
                    </td>
                    <td class="text-center">
                        <button type="button" class="btn btn-sm btn-secondary" data-toggle="tooltip" title="View Customer">
                            <i class="fa fa-user"></i>
                        </button>
                    </td>
                </tr>
                <tr>
                    <td class="text-center">12</td>
                    <td class="font-w600">Lori Grant</td>
                    <td class="d-none d-sm-table-cell">customer12@example.com</td>
                    <td class="d-none d-sm-table-cell">
                        <span class="badge badge-warning">Trial</span>
                    </td>
                    <td class="text-center">
                        <button type="button" class="btn btn-sm btn-secondary" data-toggle="tooltip" title="View Customer">
                            <i class="fa fa-user"></i>
                        </button>
                    </td>
                </tr>
                <tr>
                    <td class="text-center">13</td>
                    <td class="font-w600">Andrea Gardner</td>
                    <td class="d-none d-sm-table-cell">customer13@example.com</td>
                    <td class="d-none d-sm-table-cell">
                        <span class="badge badge-info">Business</span>
                    </td>
                    <td class="text-center">
                        <button type="button" class="btn btn-sm btn-secondary" data-toggle="tooltip" title="View Customer">
                            <i class="fa fa-user"></i>
                        </button>
                    </td>
                </tr>
                <tr>
                    <td class="text-center">14</td>
                    <td class="font-w600">Brian Cruz</td>
                    <td class="d-none d-sm-table-cell">customer14@example.com</td>
                    <td class="d-none d-sm-table-cell">
                        <span class="badge badge-info">Business</span>
                    </td>
                    <td class="text-center">
                        <button type="button" class="btn btn-sm btn-secondary" data-toggle="tooltip" title="View Customer">
                            <i class="fa fa-user"></i>
                        </button>
                    </td>
                </tr>
                <tr>
                    <td class="text-center">15</td>
                    <td class="font-w600">Marie Duncan</td>
                    <td class="d-none d-sm-table-cell">customer15@example.com</td>
                    <td class="d-none d-sm-table-cell">
                        <span class="badge badge-success">VIP</span>
                    </td>
                    <td class="text-center">
                        <button type="button" class="btn btn-sm btn-secondary" data-toggle="tooltip" title="View Customer">
                            <i class="fa fa-user"></i>
                        </button>
                    </td>
                </tr>
                <tr>
                    <td class="text-center">1</td>
                    <td class="font-w600">David Fuller</td>
                    <td class="d-none d-sm-table-cell">customer1@example.com</td>
                    <td class="d-none d-sm-table-cell">
                        <span class="badge badge-primary">Personal</span>
                    </td>
                    <td class="text-center">
                        <button type="button" class="btn btn-sm btn-secondary" data-toggle="tooltip" title="View Customer">
                            <i class="fa fa-user"></i>
                        </button>
                    </td>
                </tr>
                <tr>
                    <td class="text-center">2</td>
                    <td class="font-w600">Alice Moore</td>
                    <td class="d-none d-sm-table-cell">customer2@example.com</td>
                    <td class="d-none d-sm-table-cell">
                        <span class="badge badge-success">VIP</span>
                    </td>
                    <td class="text-center">
                        <button type="button" class="btn btn-sm btn-secondary" data-toggle="tooltip" title="View Customer">
                            <i class="fa fa-user"></i>
                        </button>
                    </td>
                </tr>
                <tr>
                    <td class="text-center">3</td>
                    <td class="font-w600">Henry Harrison</td>
                    <td class="d-none d-sm-table-cell">customer3@example.com</td>
                    <td class="d-none d-sm-table-cell">
                        <span class="badge badge-danger">Disabled</span>
                    </td>
                    <td class="text-center">
                        <button type="button" class="btn btn-sm btn-secondary" data-toggle="tooltip" title="View Customer">
                            <i class="fa fa-user"></i>
                        </button>
                    </td>
                </tr>
                <tr>
                    <td class="text-center">4</td>
                    <td class="font-w600">Judy Ford</td>
                    <td class="d-none d-sm-table-cell">customer4@example.com</td>
                    <td class="d-none d-sm-table-cell">
                        <span class="badge badge-primary">Personal</span>
                    </td>
                    <td class="text-center">
                        <button type="button" class="btn btn-sm btn-secondary" data-toggle="tooltip" title="View Customer">
                            <i class="fa fa-user"></i>
                        </button>
                    </td>
                </tr>
                <tr>
                    <td class="text-center">5</td>
                    <td class="font-w600">Laura Carr</td>
                    <td class="d-none d-sm-table-cell">customer5@example.com</td>
                    <td class="d-none d-sm-table-cell">
                        <span class="badge badge-info">Business</span>
                    </td>
                    <td class="text-center">
                        <button type="button" class="btn btn-sm btn-secondary" data-toggle="tooltip" title="View Customer">
                            <i class="fa fa-user"></i>
                        </button>
                    </td>
                </tr>
                <tr>
                    <td class="text-center">6</td>
                    <td class="font-w600">Albert Ray</td>
                    <td class="d-none d-sm-table-cell">customer6@example.com</td>
                    <td class="d-none d-sm-table-cell">
                        <span class="badge badge-primary">Personal</span>
                    </td>
                    <td class="text-center">
                        <button type="button" class="btn btn-sm btn-secondary" data-toggle="tooltip" title="View Customer">
                            <i class="fa fa-user"></i>
                        </button>
                    </td>
                </tr>
                <tr>
                    <td class="text-center">7</td>
                    <td class="font-w600">Helen Jacobs</td>
                    <td class="d-none d-sm-table-cell">customer7@example.com</td>
                    <td class="d-none d-sm-table-cell">
                        <span class="badge badge-success">VIP</span>
                    </td>
                    <td class="text-center">
                        <button type="button" class="btn btn-sm btn-secondary" data-toggle="tooltip" title="View Customer">
                            <i class="fa fa-user"></i>
                        </button>
                    </td>
                </tr>
                <tr>
                    <td class="text-center">8</td>
                    <td class="font-w600">Danielle Jones</td>
                    <td class="d-none d-sm-table-cell">customer8@example.com</td>
                    <td class="d-none d-sm-table-cell">
                        <span class="badge badge-warning">Trial</span>
                    </td>
                    <td class="text-center">
                        <button type="button" class="btn btn-sm btn-secondary" data-toggle="tooltip" title="View Customer">
                            <i class="fa fa-user"></i>
                        </button>
                    </td>
                </tr>
                <tr>
                    <td class="text-center">9</td>
                    <td class="font-w600">Jose Wagner</td>
                    <td class="d-none d-sm-table-cell">customer9@example.com</td>
                    <td class="d-none d-sm-table-cell">
                        <span class="badge badge-danger">Disabled</span>
                    </td>
                    <td class="text-center">
                        <button type="button" class="btn btn-sm btn-secondary" data-toggle="tooltip" title="View Customer">
                            <i class="fa fa-user"></i>
                        </button>
                    </td>
                </tr>
                <tr>
                    <td class="text-center">10</td>
                    <td class="font-w600">Betty Kelley</td>
                    <td class="d-none d-sm-table-cell">customer10@example.com</td>
                    <td class="d-none d-sm-table-cell">
                        <span class="badge badge-danger">Disabled</span>
                    </td>
                    <td class="text-center">
                        <button type="button" class="btn btn-sm btn-secondary" data-toggle="tooltip" title="View Customer">
                            <i class="fa fa-user"></i>
                        </button>
                    </td>
                </tr>
                <tr>
                    <td class="text-center">11</td>
                    <td class="font-w600">Betty Kelley</td>
                    <td class="d-none d-sm-table-cell">customer11@example.com</td>
                    <td class="d-none d-sm-table-cell">
                        <span class="badge badge-info">Business</span>
                    </td>
                    <td class="text-center">
                        <button type="button" class="btn btn-sm btn-secondary" data-toggle="tooltip" title="View Customer">
                            <i class="fa fa-user"></i>
                        </button>
                    </td>
                </tr>
                <tr>
                    <td class="text-center">12</td>
                    <td class="font-w600">Lori Grant</td>
                    <td class="d-none d-sm-table-cell">customer12@example.com</td>
                    <td class="d-none d-sm-table-cell">
                        <span class="badge badge-warning">Trial</span>
                    </td>
                    <td class="text-center">
                        <button type="button" class="btn btn-sm btn-secondary" data-toggle="tooltip" title="View Customer">
                            <i class="fa fa-user"></i>
                        </button>
                    </td>
                </tr>
                <tr>
                    <td class="text-center">13</td>
                    <td class="font-w600">Andrea Gardner</td>
                    <td class="d-none d-sm-table-cell">customer13@example.com</td>
                    <td class="d-none d-sm-table-cell">
                        <span class="badge badge-info">Business</span>
                    </td>
                    <td class="text-center">
                        <button type="button" class="btn btn-sm btn-secondary" data-toggle="tooltip" title="View Customer">
                            <i class="fa fa-user"></i>
                        </button>
                    </td>
                </tr>
                <tr>
                    <td class="text-center">14</td>
                    <td class="font-w600">Brian Cruz</td>
                    <td class="d-none d-sm-table-cell">customer14@example.com</td>
                    <td class="d-none d-sm-table-cell">
                        <span class="badge badge-info">Business</span>
                    </td>
                    <td class="text-center">
                        <button type="button" class="btn btn-sm btn-secondary" data-toggle="tooltip" title="View Customer">
                            <i class="fa fa-user"></i>
                        </button>
                    </td>
                </tr>
                <tr>
                    <td class="text-center">15</td>
                    <td class="font-w600">Marie Duncan</td>
                    <td class="d-none d-sm-table-cell">customer15@example.com</td>
                    <td class="d-none d-sm-table-cell">
                        <span class="badge badge-success">VIP</span>
                    </td>
                    <td class="text-center">
                        <button type="button" class="btn btn-sm btn-secondary" data-toggle="tooltip" title="View Customer">
                            <i class="fa fa-user"></i>
                        </button>
                    </td>
                </tr>
                </tbody>
            </table>
            <!--End Tables GM -->
        </div>
        <!-- END Main Content -->
        <!-- END Page Content -->
    </main>

@endsection

@push('styles')
    <link rel="stylesheet" href="/codebase/js/plugins/datatables/dataTables.bootstrap4.min.css">
@endpush

@push('scripts')
    <!-- Page JS Plugins -->
    <script src="/codebase/js/plugins/datatables/jquery.dataTables.min.js"></script>
    <script src="/codebase/js/plugins/datatables/dataTables.bootstrap4.min.js"></script>

    <!-- Page JS Code -->
    <script src="/codebase/js/pages/be_tables_datatables.js"></script>
@endpush